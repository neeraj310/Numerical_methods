s=0;
for k=1:1000
    s=s+k^2;
end

%%
p=1;
k=1;
while k<=100
    p=p*k;
    k=k+1;
end

disp(p)
factorial(100)