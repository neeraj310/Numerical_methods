function [ y ] = power8( x )
%We compute the 8th power of the input
%Input 1 real, output 1 real
y=x^8;

end

