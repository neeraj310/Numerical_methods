function [ y1,y2 ] = Multi_inout_function( x1,x2,x3 )
%Testing multiple in and out

y1=x1;
y2=x2+x3;

end

