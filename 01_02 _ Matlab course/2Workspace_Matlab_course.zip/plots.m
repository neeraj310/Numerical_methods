x=linspace(0,1,100);
y1=sin(x);

fig=figure()
plot(x,y1)
title('baò')
savefig('plot1')
saveas(fig,'bla','png')
close

%%
fig2=figure()
y2=cos(x);
plot(x,y1,'b--');
hold on
plot(x,y2,'r-.')
savefig(fig2,'second_plot')