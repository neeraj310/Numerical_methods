function [x] = my_newton(f,df,x0, tol)
%Newton algorithm with check on the distance 
%between two consecutive points
err=tol*2;
xnp1=x0;
xn=x0;
while (err>tol)
    xnp1=xn-f(xn)/df(xn);
    err=abs(xnp1-xn);
    xn=xnp1;
end
x=xnp1;
end