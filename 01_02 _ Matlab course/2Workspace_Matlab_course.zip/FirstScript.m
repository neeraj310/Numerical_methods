% documentaion of frst script
z=23; % first assignment
hallo=z*14
%{
blabla
%}

%% New section difference
b=hallo-z; 
d=b*14;
var3=power8(d);

%%
x=3;
if x==5
    y=x;
elseif x>5
    y=2*x;
else
    y=0;
end

%%
for k=1:10
    disp(k^2)
end

%%
k=10;
while k>5
    disp(k*2)
    k=k+1;
end