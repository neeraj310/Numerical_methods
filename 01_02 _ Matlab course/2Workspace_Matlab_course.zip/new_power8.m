function [ y ] = new_power8( x )

y=my_power4(x)^2;

end

function y = my_power4(x)
 y=x^4;

end
