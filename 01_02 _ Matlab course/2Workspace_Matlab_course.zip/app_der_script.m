f=@(x) sin(x);
df=@(x) cos(x);

x0=1.2;
N=20;
exdf=df(x0);

hs=zeros(N,1);
app_df=zeros(N,1);
errors=zeros(N,1);

for k=1:N
    h=1/2^k;
    app_df(k)=approx_der(f,x0,h);
    hs(k)=h;
    errors(k)=abs(exdf-app_df(k));
end

plot(hs,errors)
