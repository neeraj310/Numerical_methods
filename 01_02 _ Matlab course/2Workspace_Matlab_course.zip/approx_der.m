function [ df ] = approx_der( f, x0, h)
%Approximate derivative of f in x0 with increment h

df=(f(x0+h)-f(x0))/h;


end

