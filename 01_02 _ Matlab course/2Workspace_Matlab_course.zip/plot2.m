x=linspace(0,1);
f=exp(x/10).*sin(2*pi*x);
g=log(3+x).*cos(4*pi*x);

fig=figure()
plot(x,f,'r--')
hold on
plot(x,g,'b-.')
title('Cute functions')
xlabel('Time')
ylabel('Money')
axis([0 1 -2 2])
legend('Marc', 'John')
savefig(fig,'my_cute_functions')
close all