function [x,iter] = Broyden(F,x0,B0,tol,itMax)
%BROYDEN Summary of this function goes here
%   Detailed explanation goes here
x=x0;
f=F(x);
B=B0;
iter=0;
err = tol+1;


while (iter<=itMax) && (err >= tol)
    
    p=B\(-f);
    x_o=x;
    x=x+p;
    new_f=F(x);
    deltaF=new_f-f;
    B = B +((deltaF-B*p)*p')/(p'*p);
    f=new_f;
    err=norm(x-x_o)+ norm(f); 
    iter=iter+1;
    
end

