function x=backward_sub(U,b)
%U upper triangular, returns Ux=b
n=size(b,1);
x=zeros(size(b));
for k=n:-1:1
    x(k)=b(k);
    for z=n:-1:k+1
        x(k)=x(k)-x(z)*U(k,z);
    end
    x(k)=x(k)/U(k,k);
end
end
