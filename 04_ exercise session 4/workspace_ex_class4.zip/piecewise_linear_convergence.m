%We perform a piece-wise linear interpolation of N value points (xi,f(xi)) of a
%function f. We check the order of convergence with respect to h =1/N . We
%compute the error on a set of m points with m>>N.

f=@(x) sinc(x);

a=-5;
b=5;

%test points
M=1000;
xx = linspace(a,b,M);
yy_exact=f(xx);

Ns=2.^(3:10);
hs=(b-a)./Ns;
errs = zeros(size(hs));

for z = 1:length(hs)
    %interpolation points
    N=Ns(z)+1;
    h=hs(z);
    x_inter = linspace(a,b,N);
    y_inter = f(x_inter);
    
    yy = piecewise_linear(x_inter, y_inter, xx);
    
%     yy = spline(x_inter,y_inter, xx);
    
%     % Plot
%     plot(xx,yy, 'r')
%     hold on
%     plot(xx,yy_exact,'b')
%     plot(x_inter, y_inter, 'b*')
    
    % compute the error on the points xx
    errs(z) = norm(yy-yy_exact,2);
end

loglog(hs,errs)
hold on
loglog(hs, hs,'--')
loglog(hs, hs.^2,'--')
loglog(hs, hs.^3,'--')
loglog(hs, hs.^4,'--')
title('Error decay vs orders')
xlabel('h')
ylabel('error')
legend({'error','linear','quadratic','cubic','4th or'}, 'Location','southeast')