clc ; clear all ; close all ;

xx = [0, 7, 14, 21, 28, 35];
yy = [100, 98, 80, 92, 75, 70];
chi = 42;

n = length(xx) -1;
a = xx(1);
b = chi;

p_leg =zeros(1,4);
zz = linspace(a,b,100);

figure(1);
hold on
plot(xx,yy, 'ko','MarkerSize',4, 'Linewidth',2);

pn = polyfit(xx,yy,n);
p_val = polyval(pn,zz);
polyn = plot(zz,p_val, 'Linewidth',1);
pn_chi = polyval(pn,chi);

idx = [n,n+1];
p1 = polyfit(xx(idx),yy(idx),1);
z1 = linspace(xx(n),chi,50);
p1_val = polyval(p1,z1);
poly1 = plot(z1,p1_val, 'Linewidth',1);
p1_chi = polyval(p1,chi);

ls1 = polyfit(xx,yy,1);
ls1_val = polyval(ls1,zz);
pls1 = plot(zz,ls1_val, 'Linewidth',1);
ls1_chi = polyval(ls1,chi);

ls2 = polyfit(xx,yy,2);
ls2_val = polyval(ls2,zz);
pls2 = plot(zz,ls2_val, 'Linewidth',1);
ls2_chi = polyval(ls2,chi);

legend('data', '\Pi_5(x)', '\Pi_1(x)', 'LS m=1', 'LS m=2', 'Location','Northwest')
title('Interpolation polynomial vs. least-squares method')
legend('Location','Southwest')
axis([0 42 50 120])

%Extrapolation
fprintf(' Extrapolation at x=%d: \n', chi)
fprintf('  from P_%d: %8.4f\n', n, pn_chi)
fprintf('  from P_%d: %8.4f\n', 1, p1_chi)
fprintf('  from LS_%d: %8.4f\n', 1, ls1_chi)
fprintf('  from LS_%d: %8.4f\n', 2, ls2_chi)

