clc ; clear all ; close all ;

a =-2;
b = 2;
f = @(x) 1./(1+ 25*x.^2);

n_all = [4, 9, 19];
colors =[ [209 95 13]', [224 182 74]', [13 121 209]']/255;

zz = linspace(a,b,100);
ff = f(zz);
p_leg =zeros(1,4);

figure(1)
hold on;
for i = 1:length(n_all)
    n = n_all(i);
    xx = linspace(a,b,n+1);
    yy = f(xx);
    pn = polyfit(xx,yy,n);
    p_val = polyval(pn,zz);
    p_leg(i) = plot(zz,p_val,'Color',colors(:,i), 'Linewidth',1);
    plot(xx,polyval(pn,xx), 'o','MarkerSize',4,'MarkerEdgeColor',colors(:,i)*0.8, 'Linewidth',2);
end
p_leg(4)=plot(zz,ff, 'k--','Linewidth',1.2);
legend(p_leg,'\Pi_4','\Pi_9','\Pi_{19}','f')
title('Interpolation on equispaced nodes')
axis([a,b, -1, 10])
print('Runge_equi','-dpdf');
axis([a,b, -1, 2])
print('Runge_equi_zoom','-dpdf');

figure(2)
hold on;
for i = 1:length(n_all)
    n = n_all(i);
    tt = cos ( pi*(2*[1: n+1 ] - 1)/ (2*(n+1)) );
    xx = 0.5*( a + b ) + 0.5*( b - a )*tt;
    
    yy = f(xx);
    pn = polyfit(xx,yy,n);
    p_val = polyval(pn,zz);
    p_leg(i)= plot(zz,p_val, 'Color',colors(:,i), 'Linewidth',1);
    plot(xx,polyval(pn,xx), 'o','MarkerSize',4,'MarkerEdgeColor',colors(:,i)*0.8, 'Linewidth',2);
end
p_leg(4)=plot(zz,ff, 'k--','Linewidth',1.2);
legend(p_leg,'\Pi_4','\Pi_9','\Pi_{19}','f')
title('Interpolation on Chebyshev nodes')
axis([a,b, -1, 2])
print('Runge_cheb','-dpdf');





    
