function [yy] = piecewise_linear(x_inter, y_inter, xx)
% Piecewise linear interpolation in points (x_inter, y_inter)
% For every point x in xx, find the interval where x \in [xi, xi+1]
% If x < xmin then f(x)=f(xmin) and if x>xmax f=f(xmax), else
% Compute f(x) = ((xi+1-x)*f(xi) + (x-xi)*f(xi+1)) /(xi+1-xi)

% sort the points xi
[x_new, order] = sort(x_inter);
y_new = y_inter(order);

N=length(x_new);
M=length(xx);

yy=zeros(size(xx));

for m = 1:M
    x=xx(m);
    k=1;
    while(x>x_new(k) && k<=N)
        k=k+1;
    end
    idx1=k-1;
    idx2= k;
    if idx1<1
        yy(m)=y_new(1);
    elseif idx2>N
        yy(m)=y_new(N);
    else    
        yy(m) = ((x_new(idx2)-x)*y_new(idx1) + (x-x_new(idx1))*y_new(idx2)) /(x_new(idx2)-x_new(idx1));
    end    
end

end

