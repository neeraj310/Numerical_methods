%We perform a piece-wise linear interpolation of N value points (xi,f(xi)) of a
%function f. We check the order of convergence with respect to h =1/N . We
%compute the error on a set of m points with m>>N.

f=@(x) sinc(x);

a=-5;
b=5;

%test points
M=1000;
xx = linspace(a,b,M);
yy_exact=f(xx);

%interpolation points
el= 15; %number of intervals
N=el+1; % number of points
x_inter = linspace(a,b,N);
y_inter = f(x_inter);


%piecewise linear
yy = piecewise_linear(x_inter, y_inter, xx);

%piecewise cubic
% yy = spline(x_inter,y_inter,xx);


% Plot
plot(xx,yy, 'r')
hold on
plot(xx,yy_exact,'b')
plot(x_inter, y_inter, 'b*')

% compute the error on the points xx
err = norm(yy-yy_exact,2);

disp(err)
