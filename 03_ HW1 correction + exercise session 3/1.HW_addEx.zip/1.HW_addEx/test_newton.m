tol=5e-9;

N=4;

fs=cell(N,1);
dfs=cell(N,1);
fs{1}=@(x) x^2-9;
dfs{1}=@(x) 2*x;
fs{2}=@(x) (x-4)^2;
dfs{2}=@(x) 2*(x-4);
fs{3}=@(x) tanh(x);
dfs{3}=@(x) 1 - tanh(x)^2;
fs{4}=@(x) tanh(x);
dfs{4}=@(x) 1 - tanh(x)^2;

x0s=[0.1,0.1,2., 0.1];

for k = 1:N
    f=fs{k};
    df=dfs{k};

    x0=x0s(k);
    [x,it,xs]=newtonmethod(f,df,x0,tol,1000);

    %plot the convergence
    % Knowing that e^{k} = C(e^{k-1})^p, if we plot in loglog
    % we see that log(e^{k}) = log(C) +p*log(e^{k-1})
    % which is a line with slope p
    figure()
    loglog(abs(xs(1:end-2)-x),abs(xs(2:end-1)-x))
    xlabel('error at iter k')
    ylabel('error at iter k+1')
    hold on
    ee=abs(xs(1:end-1)-x);
    % we print different lines to find p
    for z=1:4
        loglog(ee(1:-1),ee(1:-1).^z,'--')
    end
    legend('error', 'order 1', 'order 2', 'order 3', 'order 4')
    title(func2str(f))

    
    %We can approximate p with the formula 
    %p = log(e^{k+1}/e^{k})/log(e^{k}/e^{k-1})
    
    if length(ee)>2
        approx_expon=(log(ee(end))- log(ee(end-1)))/(log(ee(end-1))-log(ee(end-2)));
    
        fprintf('The approximated exponent is %f \n',approx_expon);
    end
    
    %Knowing p, we can approximate the constant C with the formula
    %p=e^{k+1}/(e^{k})^p (in the plot if the value is converging to a
    %finite number different from zero, than we know we used the correct p
    r1=abs((xs(3:end)-xs(2:end-1)))./abs(xs(2:end-1)-xs(1:end-2));
    r2=abs((xs(3:end)-xs(2:end-1)))./abs(xs(2:end-1)-xs(1:end-2)).^2;
    r3=abs((xs(3:end)-xs(2:end-1)))./abs(xs(2:end-1)-xs(1:end-2)).^3;

    figure()
    semilogy(r1)
    hold on
    semilogy(r2)
    semilogy(r3)
    legend('ratio1','ratio2', 'ratio3')
    title(func2str(f))
    savefig(sprintf('plot_fig%d',k))
    disp('Type anything to continue with the next function')
    pause
    close all
end