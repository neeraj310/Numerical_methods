function [x, it, xs] = newtonmethod(f, df, x0,tol, itMax)

err=abs(f(x0));
xs=[x0];
it = 0;
while(err>tol && it<=itMax )
    x1= x0- f(x0)/df(x0);
    err=abs(x1-x0)+abs(f(x1));
    x0=x1;
    it=it+1;
    xs=[xs,x1];
end

if (err<tol)
    fprintf('Convergence obtained with %d iteration and error %f \n',it,err)
else
    fprintf('Not converged with %d iteration and error %f \n',it,err)
end
x=x1;
end

