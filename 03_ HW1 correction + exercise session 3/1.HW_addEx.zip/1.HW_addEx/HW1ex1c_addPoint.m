clear all; clc; close all;

tol = 0.0015;
N = tolerance_series(tol);

partial_sum=zeros(N,1);
a=@(k) 1/(2*k-1)^2;

partial_sum(1)=a(1);
for k=2:N
    partial_sum(k)=partial_sum(k-1)+a(k);
end

figure()
plot(partial_sum,'b.')
hold on
plot(pi^2/8*ones(size(partial_sum)),'r--')
xlabel('N')
ylabel('value')