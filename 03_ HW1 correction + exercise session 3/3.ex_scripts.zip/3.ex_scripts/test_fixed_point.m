% test fixed point iteration

f=@(x) exp(-x)-x;
g=@(x) f(x) +x;

%not converging example
%g=@(x) ((x-1/10).*(x-1/2).*(x-9/10))*11+1/2;
%f=@(x) g(x)-x;

x0=1;
tol=1e-7;
maxit=1000;

[z,xs]=fixed_point(g,x0,tol,maxit);

xx=linspace(0,1,100);
plot(xx,g(xx))
hold on
plot(xx,xx)
plot(z,z,'*')
title('Fixed point iteration process')
% legend('g','x')
for k=1:length(xs)
    plot(xs(k),g(xs(k)),'+')
    pause(2./k)
end
  
%%
% We know the behaviour of the error is e^{k+1} = L e^{k} = L^k e^{0}
% If we plot the log(e^{k}) = k* log(L) + b:  a line with slope L the
% lipschitz constant
figure()
iters=1:length(xs);
errs=abs(xs-z);
semilogy(errs)
hold on
% We can approximate the lipschitz constant as L^k = e^{k}/e^{0}
% In this case L^(k-1) =  e^{k}/e^{1}
k=iters(end-2);
lipsch = exp(log(errs(k)/errs(1))/(k-1));
fprintf('The approximated lipschitz constant is %f \n', lipsch)
semilogy(lipsch.^iters,'--')
title('Error of fixed point iteration')
xlabel('k number of iteration')
ylabel('Error')
legend('error', 'ref')