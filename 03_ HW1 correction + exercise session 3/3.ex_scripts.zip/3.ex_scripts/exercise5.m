clc ; clear all ; close all ;

% Exercise3
year = [2000, 2005, 2010, 2015];
east = [67.7, 68.5, 70.9, 72.8];
west = [78.3, 79.6, 80.7, 81.5];

% Evaluation data .
x = [2003, 2011, 2021];

% polyfit
% p = polyfit(x,y,n) returns the coefficients for a polynomial p(x) of
% degree n that is a best fit (in a least-squares sense) for the data in y.
% The coefficients in p are in descending powers, and the length of p is n+1
% REMIND: least-squares with m=n is equal to the polynomial interpolation.
n = 3;
a_east = polyfit(year, east, n);
a_west = polyfit(year, west, n);

fprintf("The coefficient of the interpolating polynomial of degree %d are:\n", n);
fmt = repmat('%12.5e ', 1, n+1);
fprintf(1, strcat("East: ",fmt,"\n"), flip(a_east));
fprintf(1, strcat("West: ",fmt,"\n"), flip(a_west));

%Evaluation at given x
eval_east = polyval(a_east, x);
eval_west = polyval(a_west, x);

fprintf(1,"Comparison with monomial\n");
fprintf(1, "East:  ");
mon_east = monomial(year, east, x);
fprintf(1, "West:  ");
mon_west = monomial(year, west, x);

fprintf(1,"Comparison with Lagrange\n");
lag_east = lagrange(year, east, x);
lag_west = lagrange(year, west, x);


%Results
fprintf(1, "%10s  %8s  %8s  %8s\n", ' ', 'polyfit', 'monomial', 'lagrange');
for i=1:length(x)
    fprintf(1, "%i4 %4s:  %8.5f  %8.5f  %8.5f\n", x(i), "EAST", ...
        eval_east(i), mon_east(i),lag_east(i));
    fprintf(1, "%i4 %4s:  %8.5f  %8.5f  %8.5f\n", x(i), "WEST", ...
        eval_west(i), mon_west(i),lag_west(i));
end


x_plot = linspace(2000,2015,100);
y_plotE = polyval(a_east,x_plot);
y_plotW = polyval(a_west,x_plot);

figure(1)
hold on;
plot(year,east,'ro','LineWidth',2);
plot(year,west,'bo','LineWidth',2);
plot(x_plot,y_plotE,'r--','LineWidth',2);
plot(x_plot,y_plotW,'b--','LineWidth',2);
axis ([1995 2020 65 85]);
legend('East data ', 'West data', 'East polyfit', 'West polyfit','Location','northwest')
print('Exerc3','-dpng');
