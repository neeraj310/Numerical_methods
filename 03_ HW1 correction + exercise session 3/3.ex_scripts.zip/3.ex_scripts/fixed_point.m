function [x1,xs] = fixed_point(g,x0,tol, maxIt)

err=tol*2;
it=0;
xs=[x0];
while (err>tol && it< maxIt)
    x1=g(x0);
    err=abs(x0-x1);
    it=it+1;
    x0=x1;
    xs=[xs;x1];
end

if (err<tol)
    fprintf('Convergence obtained with %d iteration and error %8.15f \n',it,err)
else
    fprintf('Not converged \n')
end
    
end