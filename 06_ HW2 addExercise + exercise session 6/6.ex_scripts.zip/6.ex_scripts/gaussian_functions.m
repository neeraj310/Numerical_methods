function [Phi] = gaussian_functions(d,s,x)
d=d-1;
x_min=min(x);
x_max=max(x);
n=length(x);
xg = ((1:d)-0.5)/d*(x_max-x_min)+x_min;
Phi = zeros(n,d+1);
Phi(:,1)=1.;
for k=1:d
    Phi(:,k+1)=exp(-((x-xg(k))/s).^2);
end

end

