clc ; clear all ; close all ;

% Exercise session 6
% Exercise 2
% to test, use the data of Exercise 1, i.e., the additional exercise of HW3

% These files are given along with the HW2
filenameA = 'StockPrices.csv';
filenameB = 'StockPrices_day.csv';
A= csvread(filenameB,2,0);
xx = A(:,1);
yy = A(:,2);
n=length(xx);

%least square
ls10= polyfit(xx,yy,10);
y10=polyval(ls10, xx);

x_dis=linspace(1,xx(end),2000);

%% Least approx via pseudo inverse XX*a=y-> XX^T*XX*a = XX^T*y

m=5;
XX = zeros(n,m+1);
for i=1:n
    for j=1:m+1
        XX(i,j)=xx(i)^(j-1);
    end
end

%Build the pseudo inverse matrix
pseudo_inv=XX'*XX;
aa = pseudo_inv^-1*XX'*yy;

fprintf('Condition number of XX is %e \n', cond(XX))
fprintf('Condition number of XX^T XX is %e \n', cond(pseudo_inv))
plot(xx,XX*aa,'DisplayName','my least square')
%% QR decomposition

[Q,R]=qr(XX);
fprintf('Condition number of Q is %f \n', cond(Q))
fprintf('Condition number of R is %e \n', cond(R))

Qtilde=Q(:,1:m+1);
Rtilde=R(1:m+1,:);
aa2= Rtilde\(Qtilde'*yy);
figure(3)
plot(xx,XX*aa,'DisplayName','my least square')
hold on
plot(xx,yy,'k.','MarkerSize',10);
plot(xx,XX*aa2,'DisplayName','QR')

xlabel('Day');
title("Daily price");
legend('Location','Northwest')
%% Gaussian functions

figure(2)
plot(xx,yy,'k.','MarkerSize',10);
hold on;
plot(xx,y10,'color',[1 0.7 0],'LineWidth',1,'DisplayName','m=10');


d=10;
s=0.3*(max(xx)-min(xx))/d;
% gaussian_functions = @(x) [ones(size(x)), exp(-((x-120)/50).^2),exp(-((x-260)/50).^2) ];
PHI=gaussian_functions(d,s,xx);
a = (PHI'*PHI)\(PHI'*yy);
plot(x_dis,gaussian_functions(d,s,x_dis')*a,'DisplayName','gaussian')

xlabel('Day');
title("Daily price");
legend('Location','Northwest')
