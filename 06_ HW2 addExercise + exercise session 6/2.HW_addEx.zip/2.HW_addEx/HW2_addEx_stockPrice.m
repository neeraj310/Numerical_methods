clc ; clear all ; close all ;

% homework 2
% additional exercise

filenameA = 'StockPrices.csv';
filenameB = 'StockPrices_day.csv';
A= csvread(filenameB,2,0);
xx = A(:,1);
yy = A(:,2);
n=length(xx);

%least square
ls1= polyfit(xx,yy,1);
ls2= polyfit(xx,yy,2);
ls4= polyfit(xx,yy,4);
ls10= polyfit(xx,yy,10);

y1=polyval(ls1, xx);
y2=polyval(ls2, xx);
y4=polyval(ls4, xx);
y10=polyval(ls10, xx);

err1=(yy-y1).^2;
err2=(yy-y2).^2;
err4=(yy-y4).^2;
err10=(yy-y10).^2;

fprintf('Max err for d= %d is %f and sum squares is %f \n', 1,max(err1),sum(err1));
fprintf('Max err for d= %d is %f and sum squares is %f \n', 2,max(err2),sum(err2));
fprintf('Max err for d= %d is %f and sum squares is %f \n', 4,max(err4),sum(err4));
fprintf('Max err for d= %d is %f and sum squares is %f \n', 10,max(err10),sum(err10));

pspli = spline(xx,yy);
x_dis=linspace(1,xx(end),2000);
yspli = ppval(pspli,x_dis);

figure(1)
hold on;
plot(xx,yy,'k.','MarkerSize',10);
plot(x_dis, yspli,'k','DisplayName','cubic spline');
plot(xx,y1,'b--','LineWidth',2,'DisplayName','m=1');
plot(xx,y2,'r:','LineWidth',2,'DisplayName','m=2');
plot(xx,y4,'g','LineWidth',2,'DisplayName','m=4');
plot(xx,y10,'color',[1 0.7 0],'LineWidth',1,'DisplayName','m=10');

axis ([min(xx) max(xx) min(yy)*0.9 max(yy)*1.1]);
xlabel('Day');
title("Daily price");
legend('Location','Northwest')
% print('ExLeastSquareDay','-dpng');


fprintf(1, " Prediction on 15 days later: \n");
fprintf(1, "   with m=1: %8.3f \n",  polyval(ls1,xx(end)+15));
fprintf(1, "   with m=2: %8.3f \n",  polyval(ls2,xx(end)+15));
fprintf(1, "   with m=4: %8.3f \n",  polyval(ls4,xx(end)+15));
fprintf(1, "   with m=10: %8.3f \n",  polyval(ls10,xx(end)+15));
fprintf(1, "   with spline: %8.3f , what is the meaning?? \n",  ppval(pspli,xx(end)+15));


